#ifndef COMMON_H
#define COMMON_H

#define _spc_output_ << ' ' <<

#endif // COMMON_H
